module.exports = {
    //jwt 密钥
    jwtSecretKey: 'Wang',
}